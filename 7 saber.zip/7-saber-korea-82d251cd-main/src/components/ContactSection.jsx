import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { useLanguage } from './LanguageContext';
import { Phone, Mail, MapPin, Instagram } from 'lucide-react';

export default function ContactSection() {
  const { t, isDark } = useLanguage();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  const contacts = [
    {
      icon: Phone,
      label: t.contact.korea,
      value: '+82-10-2882-7557',
      flag: '🇰🇷'
    },
    {
      icon: Phone,
      label: t.contact.uzbekistan,
      value: '+998-98-877-1-778',
      flag: '🇺🇿'
    },
    {
      icon: Mail,
      label: 'Email',
      value: 'info@7saber.kr',
      href: 'mailto:info@7saber.kr'
    },
    {
      icon: Instagram,
      label: 'Instagram',
      value: '@7saberkorea',
      href: 'https://www.instagram.com/7saberkorea/'
    }
  ];

  return (
    <section id="contact" className={`relative py-32 overflow-hidden transition-colors duration-700 ${isDark ? 'bg-black' : 'bg-white'}`}>
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute inset-0" style={{
          backgroundImage: 'radial-gradient(circle at 1px 1px, black 1px, transparent 0)',
          backgroundSize: '40px 40px'
        }} />
      </div>

      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className="grid md:grid-cols-2 gap-16">
          {/* Left - Title */}
          <motion.div
            initial={{ x: -100, opacity: 0 }}
            animate={isInView ? { x: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            <span className="text-red-500 text-sm tracking-widest uppercase mb-4 block">
              Get in Touch
            </span>
            <h2 className={`text-5xl md:text-7xl font-black tracking-tighter leading-none ${isDark ? 'text-white' : 'text-black'}`}>
              {t.contact.title}
            </h2>
            
            <motion.div
              initial={{ scaleX: 0 }}
              animate={isInView ? { scaleX: 1 } : {}}
              transition={{ delay: 0.3, duration: 1 }}
              className={`h-1 w-32 mt-8 origin-left ${isDark ? 'bg-white' : 'bg-black'}`}
            />

            {/* Logo */}
            <motion.img
              initial={{ opacity: 0, y: 30 }}
              animate={isInView ? { opacity: 1, y: 0 } : {}}
              transition={{ delay: 0.5 }}
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68e3e114590b552b57676b56/2ea9e98b4_logo1.png"
              alt="7SABER"
              className="h-20 mt-12 opacity-20"
            />
          </motion.div>

          {/* Right - Contact Info */}
          <div className="space-y-8">
            {contacts.map((contact, index) => (
              <motion.div
                key={index}
                initial={{ x: 100, opacity: 0 }}
                animate={isInView ? { x: 0, opacity: 1 } : {}}
                transition={{ 
                  delay: 0.2 + index * 0.15, 
                  duration: 0.8, 
                  ease: [0.22, 1, 0.36, 1] 
                }}
                className="group"
              >
                <a
                  href={contact.href || `tel:${contact.value.replace(/[^+\d]/g, '')}`}
                  className={`flex items-start gap-6 p-6 rounded-2xl transition-all duration-500 group-hover:shadow-2xl ${isDark ? 'bg-gray-900 hover:bg-white' : 'bg-gray-50 hover:bg-black'}`}
                >
                  <div className={`w-14 h-14 rounded-full flex items-center justify-center transition-colors duration-500 group-hover:bg-red-500 ${isDark ? 'bg-white' : 'bg-black'}`}>
                    <contact.icon className={`w-6 h-6 transition-colors ${isDark ? 'text-black group-hover:text-white' : 'text-white group-hover:text-white'}`} />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      {contact.flag && <span className="text-xl">{contact.flag}</span>}
                      <span className={`text-sm tracking-widest uppercase transition-colors ${isDark ? 'text-gray-400 group-hover:text-gray-500' : 'text-gray-500 group-hover:text-gray-400'}`}>
                        {contact.label}
                      </span>
                    </div>
                    <span className={`text-xl md:text-2xl font-bold tracking-tight transition-colors ${isDark ? 'text-white group-hover:text-black' : 'text-black group-hover:text-white'}`}>
                      {contact.value}
                    </span>
                  </div>
                </a>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Logos Section */}
      <motion.div
        initial={{ opacity: 0, y: 30 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ delay: 1.2 }}
        className={`mt-24 pt-12 border-t ${isDark ? 'border-gray-800' : 'border-gray-200'}`}
      >
        <div className="max-w-7xl mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-center gap-12 md:gap-20 mb-16">
            {/* 7SABER Logo */}
            <motion.img
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/9e0dcfaee_backou7.png"
              alt="7SABER"
              className="h-32 md:h-40"
              whileHover={{ scale: 1.05 }}
            />
            
            {/* Trade House Logo */}
            <motion.img
              src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/a34781c17_backr.png"
              alt="Trade House of Uzbekistan in Korea"
              className="h-32 md:h-40"
              whileHover={{ scale: 1.05 }}
            />
          </div>
        </div>
      </motion.div>

      {/* Footer */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={isInView ? { opacity: 1 } : {}}
        transition={{ delay: 1.4 }}
        className={`mt-12 pt-8 border-t ${isDark ? 'border-gray-800' : 'border-gray-200'}`}
      >
        <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className={`text-sm ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>
            © 2024 7SABER KOREA. All rights reserved.
          </p>
          <div className="flex items-center gap-4">
            <span className="text-2xl">🇰🇷</span>
            <span className={isDark ? 'text-gray-700' : 'text-gray-300'}>×</span>
            <span className="text-2xl">🇺🇿</span>
          </div>
        </div>
      </motion.div>
    </section>
  );
}