import React, { createContext, useContext, useState } from 'react';

const translations = {
  ru: {
    nav: {
      about: 'О нас',
      products: 'Продукция',
      contact: 'Контакты'
    },
    hero: {
      tagline: 'МОСТ МЕЖДУ КУЛЬТУРАМИ',
      subtitle: 'Премиальное качество'
    },
    about: {
      title: 'О НАС',
      description: '7SABER KOREA — официальное корейское представительство международного бренда 7SABER. Мы специализируемся на производстве оригинальной корейской продукции премиального качества, сохраняя традиции и современный подход к технологиям. Наряду с этим, мы также занимаемся импортом в Южную Корею продукции под брендом 7SABER — товаров, отобранных с вниманием к деталям и культурной аутентичности. Наша миссия — создать мост между культурами, объединяя лучшее из Кореи и Узбекистана под единым брендом, которому доверяют.'
    },
    products: {
      title: 'ПРОДУКЦИЯ',
      ramen: {
        name: 'Рамен',
        desc: 'Аутентичные корейские рецепты'
      },
      energy: {
        name: 'Энергетики',
        desc: 'Заряд энергии для активной жизни'
      },
      snacks: {
        name: 'Снеки',
        desc: 'Вкусы, которые вдохновляют'
      }
    },
    contact: {
      title: 'КОНТАКТЫ',
      korea: 'Корея',
      uzbekistan: 'Узбекистан'
    }
  },
  en: {
    nav: {
      about: 'About',
      products: 'Products',
      contact: 'Contact'
    },
    hero: {
      tagline: 'BRIDGE BETWEEN CULTURES',
      subtitle: 'Premium Quality'
    },
    about: {
      title: 'ABOUT US',
      description: '7SABER KOREA is the official Korean representative office of the international brand 7SABER. We specialize in producing original Korean products of premium quality, preserving traditions while embracing modern technologies. Additionally, we import 7SABER branded products to South Korea — goods selected with attention to detail and cultural authenticity. Our mission is to create a bridge between cultures, uniting the best of Korea and Uzbekistan under a single trusted brand.'
    },
    products: {
      title: 'PRODUCTS',
      ramen: {
        name: 'Ramen',
        desc: 'Authentic Korean recipes'
      },
      energy: {
        name: 'Energy Drinks',
        desc: 'Energy boost for active life'
      },
      snacks: {
        name: 'Snacks',
        desc: 'Flavors that inspire'
      }
    },
    contact: {
      title: 'CONTACT',
      korea: 'Korea',
      uzbekistan: 'Uzbekistan'
    }
  },
  uz: {
    nav: {
      about: 'Biz haqimizda',
      products: 'Mahsulotlar',
      contact: 'Aloqa'
    },
    hero: {
      tagline: 'MADANIYATLAR O\'RTASIDAGI KO\'PRIK',
      subtitle: 'Premium sifat'
    },
    about: {
      title: 'BIZ HAQIMIZDA',
      description: '7SABER KOREA — xalqaro 7SABER brendining rasmiy Koreya vakolatxonasi. Biz an\'analarni saqlab qolgan holda zamonaviy texnologiyalarga asoslangan premium sifatli original Koreya mahsulotlarini ishlab chiqarishga ixtisoslashganmiz. Shuningdek, biz Janubiy Koreyaga 7SABER brendi ostida mahsulotlarni import qilamiz — tafsilotlar va madaniy autentiklikka e\'tibor bilan tanlangan tovarlar. Bizning vazifamiz — madaniyatlar o\'rtasida ko\'prik yaratish, Koreya va O\'zbekistonning eng yaxshisini ishonchli bitta brend ostida birlashtirish.'
    },
    products: {
      title: 'MAHSULOTLAR',
      ramen: {
        name: 'Ramen',
        desc: 'Haqiqiy Koreya retseptlari'
      },
      energy: {
        name: 'Energetik ichimliklar',
        desc: 'Faol hayot uchun energiya'
      },
      snacks: {
        name: 'Gazaklar',
        desc: 'Ilhomlantiruvchi ta\'mlar'
      }
    },
    contact: {
      title: 'ALOQA',
      korea: 'Koreya',
      uzbekistan: 'O\'zbekiston'
    }
  },
  ko: {
    nav: {
      about: '회사소개',
      products: '제품',
      contact: '연락처'
    },
    hero: {
      tagline: '문화를 잇는 다리',
      subtitle: '프리미엄 품질'
    },
    about: {
      title: '회사소개',
      description: '7SABER KOREA는 국제 브랜드 7SABER의 공식 한국 대표 사무소입니다. 우리는 전통을 보존하면서 현대 기술을 수용하여 프리미엄 품질의 오리지널 한국 제품을 생산하는 것을 전문으로 합니다. 또한, 세부 사항과 문화적 진정성에 주의를 기울여 선택한 7SABER 브랜드 제품을 한국으로 수입합니다. 우리의 사명은 문화 간의 다리를 만들어 신뢰받는 하나의 브랜드 아래 한국과 우즈베키스탄의 최고를 통합하는 것입니다.'
    },
    products: {
      title: '제품',
      ramen: {
        name: '라면',
        desc: '정통 한국 레시피'
      },
      energy: {
        name: '에너지 드링크',
        desc: '활기찬 삶을 위한 에너지'
      },
      snacks: {
        name: '스낵',
        desc: '영감을 주는 맛'
      }
    },
    contact: {
      title: '연락처',
      korea: '한국',
      uzbekistan: '우즈베키스탄'
    }
  }
};

const LanguageContext = createContext();

export function LanguageProvider({ children }) {
  const [language, setLanguage] = useState('ru');
  const [isDark, setIsDark] = useState(true);
  
  const t = translations[language];
  
  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, isDark, setIsDark }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  return useContext(LanguageContext);
}