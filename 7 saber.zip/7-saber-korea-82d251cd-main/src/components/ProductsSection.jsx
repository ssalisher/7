import React, { useRef } from 'react';
import { motion, useInView, useScroll, useTransform } from 'framer-motion';
import { useLanguage } from './LanguageContext';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';

const productImages = {
  ramen: [
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/2567daeef_2025-12-15153013.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/0e5b97e32_2025-12-15153020.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/e31302cb7_2025-12-15153006.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/c507fbbbe_2025-12-15153002.jpg'
  ],
  energy: [
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/568d7733f_2025-12-15151547.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/d86fbe2bd_2025-12-15151543.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/5f42a87ee_2025-12-15151534.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/91ae80395_2025-12-15160553.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/e2db75b43_2025-12-15160549.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/f6e021f43_2025-12-15160538.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/292ab26cd_2025-12-15160536.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/b9febd3b1_2025-12-15160534.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/35999f48d_2025-12-15151524.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/2a242299a_2025-12-15151527.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/ec7056e5c_2025-12-15151530.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/b51ec0d99_2025-12-15151540.jpg'
  ],
  snacks: [
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/e00e29872_13.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/1195b6d5c_11.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/2cc6bf093_01copy_.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/f123e7d3a_00copy.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/583d91553_01_copy.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/433bcb890_2025-12-15151419.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/3b70257b4_2025-12-15151432.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/21f25492f_2025-12-15151436.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/97f5b1d6e_2025-12-15151439.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/35999f48d_2025-12-15151524.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/2a242299a_2025-12-15151527.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/ec7056e5c_2025-12-15151530.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/b51ec0d99_2025-12-15151540.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/87ec54e53_purple1.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/8014f8b0e_purple2.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/370cf0762_purple3.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/a06ea2409_yellow1.jpg',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/31c59e581_yelloe2.jpg'
  ]
};

function ProductCard({ product, index }) {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-50px' });
  const [currentImageIndex, setCurrentImageIndex] = React.useState(0);
  
  React.useEffect(() => {
    if (product.images.length > 1) {
      const interval = setInterval(() => {
        setCurrentImageIndex((prev) => (prev + 1) % product.images.length);
      }, 7000);
      return () => clearInterval(interval);
    }
  }, [product.images.length]);
  
  return (
    <Link to={createPageUrl(`Product${product.key.charAt(0).toUpperCase() + product.key.slice(1)}`)}>
      <motion.div
        ref={ref}
        initial={{ opacity: 0, y: 100 }}
        animate={isInView ? { opacity: 1, y: 0 } : {}}
        transition={{ 
          duration: 0.8, 
          delay: index * 0.2,
          ease: [0.22, 1, 0.36, 1] 
        }}
        className="group relative cursor-pointer"
      >
        {/* Image Container */}
        <div className="relative aspect-[4/5] overflow-hidden bg-gray-900 rounded-2xl">
          <motion.img
            key={currentImageIndex}
            src={product.images[currentImageIndex]}
            alt={product.name}
            className="w-full h-full object-cover"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeInOut" }}
          />
          <motion.div 
            className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-all duration-500"
            whileHover={{ scale: 1.05 }}
          />
        
        {/* Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent" />
        
        {/* Content */}
        <div className="absolute bottom-0 left-0 right-0 p-8">
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={isInView ? { y: 0, opacity: 1 } : {}}
            transition={{ delay: 0.3 + index * 0.2 }}
          >
            <span className="text-red-500 text-sm tracking-widest uppercase">
              {String(index + 1).padStart(2, '0')}
            </span>
            <h3 className="text-3xl md:text-4xl font-black text-white mt-2 tracking-tight">
              {product.name}
            </h3>
            <p className="text-gray-400 mt-2 tracking-wide">
              {product.desc}
            </p>
          </motion.div>
        </div>

        {/* Hover Effect */}
        <motion.div
          className="absolute inset-0 border-4 border-red-500 rounded-2xl opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        />
      </div>
    </motion.div>
    </Link>
  );
}

export default function ProductsSection() {
  const { t, isDark } = useLanguage();
  const containerRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ['start end', 'end start']
  });
  
  const y = useTransform(scrollYProgress, [0, 1], [100, -100]);
  const opacity = useTransform(scrollYProgress, [0, 0.2, 0.8, 1], [0, 1, 1, 0]);

  const products = [
    { key: 'ramen', ...t.products.ramen, images: productImages.ramen },
    { key: 'energy', ...t.products.energy, images: productImages.energy },
    { key: 'snacks', ...t.products.snacks, images: productImages.snacks }
  ];

  return (
    <section id="products" className={`relative py-32 overflow-hidden transition-colors duration-700 ${isDark ? 'bg-black' : 'bg-white'}`} ref={containerRef}>
      {/* Background Text */}
      <motion.div 
        style={{ y }}
        className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 pointer-events-none"
      >
        <span className={`text-[20vw] font-black tracking-tighter whitespace-nowrap ${isDark ? 'text-white/5' : 'text-black/5'}`}>
          7SABER
        </span>
      </motion.div>

      <motion.div style={{ opacity }} className="relative z-10">
        <div className="max-w-7xl mx-auto px-6">
          {/* Section Header */}
          <div className="text-center mb-20">
            <motion.span
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="text-red-500 text-sm tracking-widest uppercase block mb-4"
            >
              Premium Selection
            </motion.span>
            <motion.h2
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ delay: 0.1 }}
              className={`text-5xl md:text-8xl font-black tracking-tighter ${isDark ? 'text-white' : 'text-black'}`}
            >
              {t.products.title}
            </motion.h2>
          </div>

          {/* Products Grid */}
          <div className="grid md:grid-cols-3 gap-8">
            {products.map((product, index) => (
              <ProductCard key={product.key} product={product} index={index} />
            ))}
          </div>
        </div>
      </motion.div>

      {/* Decorative Elements */}
      <motion.div
        initial={{ scaleY: 0 }}
        whileInView={{ scaleY: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1 }}
        className={`absolute left-8 top-32 bottom-32 w-px bg-gradient-to-b from-transparent to-transparent origin-top ${isDark ? 'via-red-500' : 'via-black/30'}`}
      />
      <motion.div
        initial={{ scaleY: 0 }}
        whileInView={{ scaleY: 1 }}
        viewport={{ once: true }}
        transition={{ duration: 1, delay: 0.3 }}
        className={`absolute right-8 top-32 bottom-32 w-px bg-gradient-to-b from-transparent to-transparent origin-top ${isDark ? 'via-white/20' : 'via-black/10'}`}
      />
    </section>
  );
}