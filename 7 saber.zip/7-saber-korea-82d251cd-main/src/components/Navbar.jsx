import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { useLanguage } from './LanguageContext';
import { Menu, X, Globe, Sun, Moon } from 'lucide-react';

const languages = [
  { code: 'ru', name: 'RU' },
  { code: 'en', name: 'EN' },
  { code: 'uz', name: 'UZ' },
  { code: 'ko', name: '한국어' }
];

export default function Navbar() {
  const { language, setLanguage, t, isDark, setIsDark } = useLanguage();
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [langOpen, setLangOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollTo = (id) => {
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
    setMobileOpen(false);
  };

  return (
    <motion.nav
      initial={{ y: -100 }}
      animate={{ y: 0 }}
      transition={{ duration: 0.6, ease: [0.22, 1, 0.36, 1] }}
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
        scrolled 
          ? isDark ? 'bg-black/95 backdrop-blur-md py-4' : 'bg-white/95 backdrop-blur-md py-4'
          : 'bg-transparent py-6'
      }`}
    >
      <div className="max-w-7xl mx-auto px-6 flex items-center justify-between">
        <motion.img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/0bcb04e60_2025-12-15214015-Photoroom.png"
          alt="7SABER"
          className="h-12 md:h-14"
          whileHover={{ scale: 1.05 }}
        />

        {/* Desktop Nav */}
        <div className="hidden md:flex items-center gap-10">
          {[
            { key: 'about', label: t.nav.about },
            { key: 'products', label: t.nav.products },
            { key: 'contact', label: t.nav.contact }
          ].map((item) => (
            <motion.button
              key={item.key}
              onClick={() => scrollTo(item.key)}
              className={`text-sm tracking-widest uppercase font-medium relative group ${isDark ? 'text-white' : 'text-black'}`}
              whileHover={{ y: -2 }}
            >
              {item.label}
              <span className="absolute -bottom-1 left-0 w-0 h-0.5 bg-red-500 transition-all duration-300 group-hover:w-full" />
            </motion.button>
          ))}

          {/* Theme Toggle */}
          <motion.button
            onClick={() => setIsDark(!isDark)}
            className={`p-2 rounded-full transition-colors ${isDark ? 'text-white hover:bg-white/10' : 'text-black hover:bg-black/10'}`}
            whileHover={{ scale: 1.1 }}
            whileTap={{ scale: 0.9 }}
          >
            {isDark ? <Sun size={20} /> : <Moon size={20} />}
          </motion.button>

          {/* Language Selector */}
          <div className="relative">
            <motion.button
              onClick={() => setLangOpen(!langOpen)}
              className={`flex items-center gap-2 text-sm tracking-wider ${isDark ? 'text-white' : 'text-black'}`}
              whileHover={{ scale: 1.05 }}
            >
              <Globe size={18} />
              {languages.find(l => l.code === language)?.name}
            </motion.button>
            
            <AnimatePresence>
              {langOpen && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: 10 }}
                  className={`absolute top-full right-0 mt-2 rounded-lg overflow-hidden border ${isDark ? 'bg-black border-white/20' : 'bg-white border-black/20'}`}
                >
                  {languages.map((lang) => (
                    <button
                      key={lang.code}
                      onClick={() => {
                        setLanguage(lang.code);
                        setLangOpen(false);
                      }}
                      className={`block w-full px-6 py-3 text-left text-sm transition-colors ${
                        language === lang.code
                          ? 'bg-red-500 text-white'
                          : isDark ? 'text-white hover:bg-white/10' : 'text-black hover:bg-black/10'
                      }`}
                    >
                      {lang.name}
                    </button>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>

        {/* Mobile Menu Button */}
        <button
          className={`md:hidden ${isDark ? 'text-white' : 'text-black'}`}
          onClick={() => setMobileOpen(!mobileOpen)}
        >
          {mobileOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: 'auto' }}
            exit={{ opacity: 0, height: 0 }}
            className={`md:hidden backdrop-blur-md ${isDark ? 'bg-black/95' : 'bg-white/95'}`}
          >
            <div className="px-6 py-8 flex flex-col gap-6">
              {[
                { key: 'about', label: t.nav.about },
                { key: 'products', label: t.nav.products },
                { key: 'contact', label: t.nav.contact }
              ].map((item) => (
                <button
                  key={item.key}
                  onClick={() => scrollTo(item.key)}
                  className={`text-lg tracking-widest uppercase font-medium text-left ${isDark ? 'text-white' : 'text-black'}`}
                >
                  {item.label}
                </button>
              ))}
              
              <div className={`flex gap-4 pt-4 border-t ${isDark ? 'border-white/20' : 'border-black/20'}`}>
                <button
                  onClick={() => setIsDark(!isDark)}
                  className={`flex items-center gap-2 px-4 py-2 border rounded ${isDark ? 'text-white border-white/30' : 'text-black border-black/30'}`}
                >
                  {isDark ? <Sun size={18} /> : <Moon size={18} />}
                  {isDark ? 'Day' : 'Night'}
                </button>
              </div>

              <div className={`flex gap-4 pt-4 border-t ${isDark ? 'border-white/20' : 'border-black/20'}`}>
                {languages.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => {
                      setLanguage(lang.code);
                      setMobileOpen(false);
                    }}
                    className={`px-4 py-2 text-sm rounded ${
                      language === lang.code
                        ? 'bg-red-500 text-white'
                        : isDark ? 'text-white border border-white/30' : 'text-black border border-black/30'
                    }`}
                  >
                    {lang.name}
                  </button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </motion.nav>
  );
}