import React from 'react';
import { LanguageProvider } from '../components/LanguageContext';
import Navbar from '../components/Navbar';
import HeroSection from '../components/HeroSection';
import AboutSection from '../components/AboutSection';
import ProductsSection from '../components/ProductsSection';
import ContactSection from '../components/ContactSection';

export default function Home() {
  return (
    <LanguageProvider>
      <div className="overflow-x-hidden">
        <Navbar />
        <HeroSection />
        <AboutSection />
        <ProductsSection />
        <ContactSection />
      </div>
    </LanguageProvider>
  );
}