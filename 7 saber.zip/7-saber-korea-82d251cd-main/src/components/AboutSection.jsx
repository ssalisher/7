import React, { useRef } from 'react';
import { motion, useInView } from 'framer-motion';
import { useLanguage } from './LanguageContext';

export default function AboutSection() {
  const { t, isDark } = useLanguage();
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: '-100px' });

  return (
    <section id="about" className={`relative py-32 overflow-hidden transition-colors duration-700 ${isDark ? 'bg-black' : 'bg-white'}`}>
      {/* Background Pattern */}
      <div className="absolute top-0 right-0 w-1/2 h-full opacity-5">
        <img
          src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/user_68e3e114590b552b57676b56/2ea9e98b4_logo1.png"
          alt=""
          className="h-full object-contain object-right"
        />
      </div>

      <div className="max-w-7xl mx-auto px-6" ref={ref}>
        <div className="grid md:grid-cols-2 gap-16 items-center">
          {/* Left - Title */}
          <div>
            <motion.div
              initial={{ x: -100, opacity: 0 }}
              animate={isInView ? { x: 0, opacity: 1 } : {}}
              transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
            >
              <img
                src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/0bcb04e60_2025-12-15214015-Photoroom.png"
                alt="7SABER KOREA"
                className="h-12 mb-4"
              />
              <h2 className={`text-5xl md:text-7xl font-black tracking-tighter leading-none ${isDark ? 'text-white' : 'text-black'}`}>
                {t.about.title}
              </h2>
            </motion.div>

            {/* Animated Line */}
            <motion.div
              initial={{ scaleX: 0 }}
              animate={isInView ? { scaleX: 1 } : {}}
              transition={{ delay: 0.3, duration: 1 }}
              className={`h-1 w-32 mt-8 origin-left ${isDark ? 'bg-white' : 'bg-black'}`}
            />

            {/* Flags */}
            <motion.div
              initial={{ y: 30, opacity: 0 }}
              animate={isInView ? { y: 0, opacity: 1 } : {}}
              transition={{ delay: 0.5 }}
              className="flex gap-4 mt-8"
            >
              <span className="text-4xl">🇰🇷</span>
              <span className="text-4xl">🇺🇿</span>
            </motion.div>
          </div>

          {/* Right - Description */}
          <motion.div
            initial={{ x: 100, opacity: 0 }}
            animate={isInView ? { x: 0, opacity: 1 } : {}}
            transition={{ delay: 0.2, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          >
            <p className={`text-lg md:text-xl leading-relaxed ${isDark ? 'text-gray-300' : 'text-gray-700'}`}>
              {t.about.description}
            </p>
          </motion.div>
        </div>

        {/* Stats */}
        <motion.div
          initial={{ y: 60, opacity: 0 }}
          animate={isInView ? { y: 0, opacity: 1 } : {}}
          transition={{ delay: 0.6, duration: 0.8 }}
          className="grid grid-cols-3 gap-8 mt-24"
        >
          {[
            { number: '27+', label: 'Countries' },
            { number: '10+', label: 'Product Lines' },
            { number: '∞', label: 'Quality', isInfinity: true }
          ].map((stat, i) => (
            <div key={i} className="text-center">
              <motion.div 
                className={`text-5xl md:text-7xl font-black ${isDark ? 'text-white' : 'text-black'}`}
                animate={stat.isInfinity ? {
                  scale: [1, 1.1, 1],
                  textShadow: [
                    '0 0 0px rgba(255,215,0,0)',
                    '0 0 20px rgba(255,215,0,0.8)',
                    '0 0 0px rgba(255,215,0,0)'
                  ]
                } : {}}
                transition={stat.isInfinity ? {
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeInOut"
                } : {}}
              >
                {stat.number}
              </motion.div>
              <div className={`text-sm tracking-widest uppercase mt-2 ${isDark ? 'text-gray-400' : 'text-gray-500'}`}>{stat.label}</div>
            </div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}