import React from 'react';
import { motion } from 'framer-motion';
import { useLanguage } from './LanguageContext';
import { ChevronDown } from 'lucide-react';

export default function HeroSection() {
  const { t, isDark } = useLanguage();
  const [currentBg, setCurrentBg] = React.useState(0);

  const nightBackgrounds = [
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/7705db832_download8.png',
    'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/355dd6439_download6.png'
  ];

  const dayBackground = 'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/75bdea812_download10.png';

  React.useEffect(() => {
    if (isDark) {
      const interval = setInterval(() => {
        setCurrentBg((prev) => (prev + 1) % nightBackgrounds.length);
      }, 8000);
      return () => clearInterval(interval);
    }
  }, [isDark]);

  const scrollToAbout = () => {
    document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <section className={`relative h-screen overflow-hidden flex items-center justify-center transition-colors duration-700 ${isDark ? 'bg-black' : 'bg-white'}`}>
        {/* Background Images */}
        <div className="absolute inset-0">
          {isDark ? (
            nightBackgrounds.map((bg, index) => (
              <motion.div
                key={bg}
                className="absolute inset-0"
                initial={{ opacity: 0 }}
                animate={{ opacity: currentBg === index ? 0.3 : 0 }}
                transition={{ duration: 2, ease: "easeInOut" }}
              >
                <img
                  src={bg}
                  alt=""
                  className="w-full h-full object-cover"
                />
              </motion.div>
            ))
          ) : (
            <motion.div
              className="absolute inset-0"
              initial={{ opacity: 0 }}
              animate={{ opacity: 0.5 }}
              transition={{ duration: 1, ease: "easeInOut" }}
            >
              <img
                src={dayBackground}
                alt=""
                className="w-full h-full object-cover"
              />
            </motion.div>
          )}
        </div>

        {/* Animated Background Grid */}
        <div className={`absolute inset-0 ${isDark ? 'opacity-10' : 'opacity-5'}`}>
          <div className="absolute inset-0" style={{
            backgroundImage: 'linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)',
            backgroundSize: '100px 100px'
          }} />
        </div>

      {/* Animated Circles */}
      <motion.div
        className={`absolute w-[600px] h-[600px] border rounded-full ${isDark ? 'border-white/5' : 'border-black/5'}`}
        animate={{ rotate: 360 }}
        transition={{ duration: 60, repeat: Infinity, ease: 'linear' }}
      />
      <motion.div
        className={`absolute w-[800px] h-[800px] border rounded-full ${isDark ? 'border-white/5' : 'border-black/5'}`}
        animate={{ rotate: -360 }}
        transition={{ duration: 80, repeat: Infinity, ease: 'linear' }}
      />

      <div className="relative z-10 text-center px-6">
        {/* Logo */}
        <motion.div
          initial={{ scale: 0, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ duration: 1, ease: [0.22, 1, 0.36, 1] }}
          className="mb-12"
        >
          <img
            src="https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/0bcb04e60_2025-12-15214015-Photoroom.png"
            alt="7SABER Korea"
            className="h-40 md:h-60 mx-auto"
          />
        </motion.div>

        {/* Tagline */}
        <motion.h1
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3, duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className={`text-4xl md:text-7xl font-black tracking-tighter mb-6 ${isDark ? 'text-white' : 'text-black'}`}
        >
          {t.hero.tagline.split(' ').map((word, i) => (
            <motion.span
              key={i}
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 + i * 0.1 }}
              className={`inline-block mr-4 ${i === 1 ? 'text-red-500' : ''}`}
            >
              {word}
            </motion.span>
          ))}
        </motion.h1>

        {/* Subtitle */}
        <motion.p
          initial={{ y: 30, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.8, duration: 0.6 }}
          className={`text-lg md:text-xl tracking-widest uppercase ${isDark ? 'text-gray-400' : 'text-gray-600'}`}
        >
          {t.hero.subtitle}
        </motion.p>

        {/* Korea Badge */}
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ delay: 1.2, type: 'spring' }}
          className={`mt-10 inline-flex items-center gap-2 px-6 py-3 border rounded-full ${isDark ? 'border-white/20' : 'border-black/20'}`}
        >
          <span className="text-2xl">🇰🇷</span>
          <span className={`text-sm tracking-widest ${isDark ? 'text-white' : 'text-black'}`}>KOREA</span>
        </motion.div>
      </div>

      {/* Scroll Indicator */}
      <motion.button
        onClick={scrollToAbout}
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5 }}
        className={`absolute bottom-10 left-1/2 -translate-x-1/2 ${isDark ? 'text-white' : 'text-black'}`}
      >
        <motion.div
          animate={{ y: [0, 10, 0] }}
          transition={{ duration: 1.5, repeat: Infinity }}
        >
          <ChevronDown size={32} />
        </motion.div>
      </motion.button>

      {/* Red accent line */}
      <motion.div
        initial={{ scaleX: 0 }}
        animate={{ scaleX: 1 }}
        transition={{ delay: 1, duration: 1.5 }}
        className="absolute bottom-0 left-0 right-0 h-1 bg-gradient-to-r from-transparent via-red-500 to-transparent"
      />
    </section>
  );
}