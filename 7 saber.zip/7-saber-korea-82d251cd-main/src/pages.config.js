import Home from './pages/Home';
import ProductRamen from './pages/ProductRamen';
import ProductEnergy from './pages/ProductEnergy';
import ProductSnacks from './pages/ProductSnacks';


export const PAGES = {
    "Home": Home,
    "ProductRamen": ProductRamen,
    "ProductEnergy": ProductEnergy,
    "ProductSnacks": ProductSnacks,
}

export const pagesConfig = {
    mainPage: "Home",
    Pages: PAGES,
};