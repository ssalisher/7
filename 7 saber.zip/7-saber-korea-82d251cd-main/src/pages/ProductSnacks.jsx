import React from 'react';
import { motion } from 'framer-motion';
import { LanguageProvider, useLanguage } from '../components/LanguageContext';
import Navbar from '../components/Navbar';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';

const snackImages = [
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/e00e29872_13.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/1195b6d5c_11.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/2cc6bf093_01copy_.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/f123e7d3a_00copy.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/583d91553_01_copy.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/433bcb890_2025-12-15151419.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/3b70257b4_2025-12-15151432.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/21f25492f_2025-12-15151436.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/97f5b1d6e_2025-12-15151439.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/87ec54e53_purple1.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/8014f8b0e_purple2.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/370cf0762_purple3.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/a06ea2409_yellow1.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/31c59e581_yelloe2.jpg'
];

function SnacksContent() {
  const { t } = useLanguage();
  const [selectedImage, setSelectedImage] = React.useState(0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-white via-gray-50 to-gray-100">
      <Navbar />
      
      <div className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Back Button */}
          <Link to={createPageUrl('Home')}>
            <motion.button
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 text-black mb-12 hover:text-red-500 transition-colors"
            >
              <ArrowLeft size={24} />
              <span className="text-lg tracking-wide">{t.nav.products}</span>
            </motion.button>
          </Link>

          <div className="grid lg:grid-cols-2 gap-16 items-start">
            {/* Images */}
            <div className="sticky top-32">
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6 }}
                className="relative aspect-square rounded-2xl overflow-hidden bg-white shadow-2xl mb-6"
              >
                <img
                  src={snackImages[selectedImage]}
                  alt="Snacks"
                  className="w-full h-full object-cover"
                />
              </motion.div>

              {/* Thumbnails Grid - Scrollable */}
              <div className="grid grid-cols-6 gap-2 max-h-[500px] overflow-y-auto pr-2 scrollbar-thin scrollbar-thumb-gray-400 scrollbar-track-gray-200 rounded">
                {snackImages.map((img, index) => (
                  <motion.button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    whileHover={{ scale: 1.05 }}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                      selectedImage === index ? 'border-red-500' : 'border-gray-300'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Content */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <span className="text-red-500 text-sm tracking-widest uppercase">Premium Snacks</span>
              <h1 className="text-6xl md:text-8xl font-black text-black mt-4 mb-6 tracking-tighter">
                {t.products.snacks.name}
              </h1>
              <p className="text-xl text-gray-700 mb-8 leading-relaxed">
                {t.products.snacks.desc}
              </p>

              {/* Product Categories */}
              <div className="mb-12">
                <h3 className="text-black text-2xl font-bold mb-6">Available Varieties</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="p-6 bg-gradient-to-br from-orange-50 to-orange-100 rounded-xl border border-orange-200">
                    <h4 className="font-bold text-black text-lg mb-2">Orange Seeds</h4>
                    <p className="text-sm text-gray-700">Premium sunflower seeds with orange flavor</p>
                  </div>
                  <div className="p-6 bg-gradient-to-br from-purple-50 to-purple-100 rounded-xl border border-purple-200">
                    <h4 className="font-bold text-black text-lg mb-2">Coconut Seeds</h4>
                    <p className="text-sm text-gray-700">Exotic coconut-flavored treats</p>
                  </div>
                  <div className="p-6 bg-gradient-to-br from-yellow-50 to-yellow-100 rounded-xl border border-yellow-200">
                    <h4 className="font-bold text-black text-lg mb-2">Original Salted</h4>
                    <p className="text-sm text-gray-700">Classic salted sunflower seeds</p>
                  </div>
                  <div className="p-6 bg-gradient-to-br from-gray-50 to-gray-100 rounded-xl border border-gray-200">
                    <h4 className="font-bold text-black text-lg mb-2">Black Pack</h4>
                    <p className="text-sm text-gray-700">Premium selection in elegant packaging</p>
                  </div>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-black text-lg">Premium sunflower seeds</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-black text-lg">Multiple flavor options</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-black text-lg">110g - 208g packages</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-black text-lg">ISO certified quality</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ProductSnacks() {
  return (
    <LanguageProvider>
      <SnacksContent />
    </LanguageProvider>
  );
}