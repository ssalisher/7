import React from 'react';
import { motion } from 'framer-motion';
import { LanguageProvider, useLanguage } from '../components/LanguageContext';
import Navbar from '../components/Navbar';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';

const ramenImages = [
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/2567daeef_2025-12-15153013.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/0e5b97e32_2025-12-15153020.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/e31302cb7_2025-12-15153006.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/c507fbbbe_2025-12-15153002.jpg'
];

function RamenContent() {
  const { t } = useLanguage();
  const [selectedImage, setSelectedImage] = React.useState(0);

  return (
    <div className="min-h-screen bg-black">
      <Navbar />
      
      <div className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Back Button */}
          <Link to={createPageUrl('Home')}>
            <motion.button
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 text-white mb-12 hover:text-red-500 transition-colors"
            >
              <ArrowLeft size={24} />
              <span className="text-lg tracking-wide">{t.nav.products}</span>
            </motion.button>
          </Link>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Images */}
            <div>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6 }}
                className="relative aspect-square rounded-2xl overflow-hidden bg-gray-900 mb-6"
              >
                <img
                  src={ramenImages[selectedImage]}
                  alt="Ramen"
                  className="w-full h-full object-cover"
                />
              </motion.div>

              {/* Thumbnails */}
              <div className="grid grid-cols-4 gap-3">
                {ramenImages.map((img, index) => (
                  <motion.button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    whileHover={{ scale: 1.05 }}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                      selectedImage === index ? 'border-red-500' : 'border-white/20'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Content */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <span className="text-red-500 text-sm tracking-widest uppercase">Premium Ramen</span>
              <h1 className="text-6xl md:text-8xl font-black text-white mt-4 mb-6 tracking-tighter">
                {t.products.ramen.name}
              </h1>
              <p className="text-xl text-gray-400 mb-8 leading-relaxed">
                {t.products.ramen.desc}
              </p>

              {/* Product Info */}
              <div className="grid grid-cols-2 gap-4 mb-8">
                <div className="bg-gradient-to-br from-red-500/20 to-red-600/10 border border-red-500/30 rounded-xl p-4">
                  <div className="text-red-400 text-sm mb-1">Weight</div>
                  <div className="text-white text-2xl font-bold">125g</div>
                </div>
                <div className="bg-gradient-to-br from-orange-500/20 to-orange-600/10 border border-orange-500/30 rounded-xl p-4">
                  <div className="text-orange-400 text-sm mb-1">Calories</div>
                  <div className="text-white text-2xl font-bold">486 Kcal</div>
                </div>
                <div className="bg-gradient-to-br from-yellow-500/20 to-yellow-600/10 border border-yellow-500/30 rounded-xl p-4">
                  <div className="text-yellow-400 text-sm mb-1">Cooking Time</div>
                  <div className="text-white text-2xl font-bold">4:30</div>
                </div>
                <div className="bg-gradient-to-br from-green-500/20 to-green-600/10 border border-green-500/30 rounded-xl p-4">
                  <div className="text-green-400 text-sm mb-1">Package</div>
                  <div className="text-white text-2xl font-bold">5 pcs</div>
                </div>
              </div>

              {/* Ingredients */}
              <div className="mb-8">
                <h3 className="text-white text-xl font-bold mb-4">Ingredients</h3>
                <div className="space-y-3">
                  <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                    <div className="text-red-400 font-semibold mb-2">Noodles (Lag'mon)</div>
                    <p className="text-gray-400 text-sm">Wheat flour with starch, oil, salt, gluten, and vitamin E</p>
                  </div>
                  <div className="bg-white/5 rounded-lg p-4 border border-white/10">
                    <div className="text-red-400 font-semibold mb-2">Soup Base (Sho'rva asosi)</div>
                    <p className="text-gray-400 text-sm">Iodized salt, vegetable mix, soy sauce powder, mushroom powder, and seasonings</p>
                  </div>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-white text-lg">Enriched with Vitamins E+B2</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-white text-lg">Halal & Korea Halal Certified</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-white text-lg">Contains: Soy, Wheat, Mushrooms</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-white text-lg">Spicy (Achiq) - Age 3+</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ProductRamen() {
  return (
    <LanguageProvider>
      <RamenContent />
    </LanguageProvider>
  );
}