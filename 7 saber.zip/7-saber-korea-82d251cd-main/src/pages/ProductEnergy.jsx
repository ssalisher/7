import React from 'react';
import { motion } from 'framer-motion';
import { LanguageProvider, useLanguage } from '../components/LanguageContext';
import Navbar from '../components/Navbar';
import { ArrowLeft } from 'lucide-react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';

const energyImages = [
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/568d7733f_2025-12-15151547.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/d86fbe2bd_2025-12-15151543.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/5f42a87ee_2025-12-15151534.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/91ae80395_2025-12-15160553.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/e2db75b43_2025-12-15160549.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/f6e021f43_2025-12-15160538.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/292ab26cd_2025-12-15160536.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/b9febd3b1_2025-12-15160534.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/35999f48d_2025-12-15151524.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/2a242299a_2025-12-15151527.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/ec7056e5c_2025-12-15151530.jpg',
  'https://qtrypzzcjebvfcihiynt.supabase.co/storage/v1/object/public/base44-prod/public/69401a2c48bb767682d251cd/b51ec0d99_2025-12-15151540.jpg'
];

function EnergyContent() {
  const { t } = useLanguage();
  const [selectedImage, setSelectedImage] = React.useState(0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-black via-gray-900 to-black">
      <Navbar />
      
      <div className="pt-32 pb-20 px-6">
        <div className="max-w-7xl mx-auto">
          {/* Back Button */}
          <Link to={createPageUrl('Home')}>
            <motion.button
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              className="flex items-center gap-2 text-white mb-12 hover:text-red-500 transition-colors"
            >
              <ArrowLeft size={24} />
              <span className="text-lg tracking-wide">{t.nav.products}</span>
            </motion.button>
          </Link>

          <div className="grid lg:grid-cols-2 gap-16 items-center">
            {/* Images */}
            <div>
              <motion.div
                initial={{ opacity: 0, scale: 0.9 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.6 }}
                className="relative aspect-square rounded-2xl overflow-hidden bg-gray-900 mb-6"
              >
                <img
                  src={energyImages[selectedImage]}
                  alt="Energy Drink"
                  className="w-full h-full object-cover"
                />
              </motion.div>

              {/* Thumbnails Grid */}
              <div className="grid grid-cols-6 gap-3">
                {energyImages.map((img, index) => (
                  <motion.button
                    key={index}
                    onClick={() => setSelectedImage(index)}
                    whileHover={{ scale: 1.05 }}
                    className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                      selectedImage === index ? 'border-red-500' : 'border-white/20'
                    }`}
                  >
                    <img src={img} alt="" className="w-full h-full object-cover" />
                  </motion.button>
                ))}
              </div>
            </div>

            {/* Content */}
            <motion.div
              initial={{ opacity: 0, y: 50 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3, duration: 0.6 }}
            >
              <span className="text-red-500 text-sm tracking-widest uppercase">7SABER Energy</span>
              <h1 className="text-6xl md:text-8xl font-black text-white mt-4 mb-6 tracking-tighter">
                {t.products.energy.name}
              </h1>
              <p className="text-xl text-gray-400 mb-8 leading-relaxed">
                {t.products.energy.desc}
              </p>

              {/* Variants */}
              <div className="mb-8">
                <h3 className="text-white text-2xl font-bold mb-4">Available Flavors</h3>
                <div className="flex flex-wrap gap-3">
                  {['Original', 'Orange', 'Mango', 'Pomegranate'].map((flavor) => (
                    <div key={flavor} className="px-6 py-3 bg-white/10 backdrop-blur rounded-full border border-white/20">
                      <span className="text-white font-medium">{flavor}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Nutrition Info */}
              <div className="mb-8 bg-gradient-to-br from-black to-gray-900 rounded-xl p-6 border border-gray-700">
                <h3 className="text-white text-xl font-bold mb-4">Supplement Facts (450ml)</h3>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between border-b border-gray-700 pb-2">
                    <span className="text-gray-400">Calories per 100ml</span>
                    <span className="text-white font-semibold">45 Kcal / 189 kDJ</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-700 pb-2">
                    <span className="text-gray-400">Taurine</span>
                    <span className="text-white font-semibold">22.5 mg</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-700 pb-2">
                    <span className="text-gray-400">Caffeine</span>
                    <span className="text-white font-semibold">4.5 mg</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-700 pb-2">
                    <span className="text-gray-400">Vitamin B6</span>
                    <span className="text-white font-semibold">0.15 mg (100%)</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-700 pb-2">
                    <span className="text-gray-400">Vitamin B12</span>
                    <span className="text-white font-semibold">0.15 mcg (200%)</span>
                  </div>
                  <div className="flex justify-between border-b border-gray-700 pb-2">
                    <span className="text-gray-400">Riboflavin (B2)</span>
                    <span className="text-white font-semibold">1.5 mg (15.6%)</span>
                  </div>
                  <div className="flex justify-between pb-2">
                    <span className="text-gray-400">Pantothenic acid</span>
                    <span className="text-white font-semibold">0.6 mg (33.3%)</span>
                  </div>
                </div>
              </div>

              {/* Features */}
              <div className="space-y-4">
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-white text-lg">Vitamin-enriched (B3, B5, B6, B12)</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-white text-lg">Carbohydrates: 11.2g per 100ml</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-white text-lg">Made in Uzbekistan - Halal certified</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-white text-lg">24x450ML | 24x330ML available</span>
                </div>
                <div className="flex items-center gap-4">
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span className="text-white text-lg">Not for under 18, pregnant/breastfeeding</span>
                </div>
              </div>
            </motion.div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ProductEnergy() {
  return (
    <LanguageProvider>
      <EnergyContent />
    </LanguageProvider>
  );
}